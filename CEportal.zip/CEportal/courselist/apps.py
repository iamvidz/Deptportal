from django.apps import AppConfig


class CourselistConfig(AppConfig):
    name = 'courselist'
