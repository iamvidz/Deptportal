from django.db import models

# Create your models here.

#class Student(models.Model):
    #college_id=models.CharField(primary_key=True)
    #student_name=models.CharField(20)
    